
#include "problem1.h"
#include <stdio.h>

void linspace(double* array, double min, double max, int n)
{
    //chcek null pointer
        if(!array) return; 
        else{
    //edge case where n <=0 error     
		if (n<=0){
			printf("invalid number of points please use n >= 1\n");
		}	
    //case where n = 1, return an array of 1 element min.
		else if(n == 1){
			*array = min;
		}
	//otherwise we calculate the steps and iterate the array n times and assign values
    		else{
        		double space = (double)(max - min)/(n-1);
        		int i;
        		for(i = 0; i<n; i++){
	    			*(array+i)=min+space*i;
			}	
		}
	}	 
}

