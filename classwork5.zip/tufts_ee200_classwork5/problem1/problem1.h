#ifndef PROBLEM1_H
#define PROBLEM1_H

void linspace(double* array, double min, double max, int n);

#endif
