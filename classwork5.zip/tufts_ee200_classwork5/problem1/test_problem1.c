
#include "problem1.h"
#include <stdio.h>
#include <stdlib.h>
//#include <stdlib.h>
int main(int argc, char* argv[])
{
  //test case 1: min = -5, max = 5, n = 7
  //test case 2: min = 0, max = 10, n = 11
  //test case 3: min = -1, max = 1, n = 1
  //test case 4: min = 1, max = 1, n = 10
  //test case 5: min = 1, max = 100, n = 0;
  double *arr = malloc(sizeof(*arr)*7);
  double *arr1 = malloc(sizeof(*arr1)*11);
  double *arr2 = malloc(sizeof(*arr2)*1);
  double *arr3 = malloc(sizeof(*arr3)*10);
  double *arr4 = NULL;
  linspace(arr, -5,5,7);
  linspace(arr1, 0,10,11);
  linspace(arr2, -1,1,1);
  linspace(arr3, 1, 1, 10);
  linspace(arr4, 1, 1, 10);
  int i;
  for(i = 0; i<7;i++){
      printf("%lf ", *(arr+i));
  }
  printf("\n");
  int j;
  for(j = 0; j<11;j++){
      printf("%lf ", *(arr1+j));
  }
  printf("\n");
  int k;
  for(k = 0;k<1;k++){
      printf("%lf ", *(arr2+k));
  }
  printf("\n");
  int x;
  for (x = 0; x<10;x++){
      printf("%lf ", *(arr3+x));

  }
  printf("\n");
  //linspace(arr4, 1, 100, 0);
  return(0);
}

