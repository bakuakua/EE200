
#include "problem3.h"
#include <stdio.h>
// helper function to print out the increassing sequence found
void test_out(int *arr, int n, int tnum){
  printf("========================================================\ntest array #%d: ", tnum);
  int i;
  for (i=0;i<10;i++) printf("%d ",*(arr+i));
  printf("\n");
  int* result = find_sequence(arr, 10);
  if (result) printf("longest increasing sequence starts with %d\n", *result);
}
int main(int argc, char* argv[])
{

  // Put anything here that you think is appropriate to test your function
  int arr[] = {7,3,4,5,6,7,0,5,3,5};
  int arr1[] = {7,3,4,5,6,1,2,3,4,5};
  int arr2[] = {10,9,8,7,6,5,4,3,2,1};
  int arr3[] = {6,6,6,6,6,6,6,6,6,6};
  test_out(arr, 10,1);
  test_out(arr1, 10,2);
  test_out(arr2, 10,3);	
  test_out(arr3, 10,4);
  return(0);
}

