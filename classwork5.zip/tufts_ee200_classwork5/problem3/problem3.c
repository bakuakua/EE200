
#include "problem3.h"
#include <stdio.h>

int* find_sequence(int* seq, int n)
{
  //traverse the sequence with two pointers
  //pointer i is the beginning of the integer sequence
  //pointer j is the end of the increasing sequence
  //the nested loops iterate throw all possible increasing sequence
  int i;
  int j;
  int length_max=1;
  int max_pos=0;
  if (seq == NULL) return NULL;
  for(i = 0; i<n; i++){
     for(j = i+1; j<n; j++){
        //check is the current sequence defined by i and j is an increasing sequence
	if(*(seq+i)<*(seq+j))continue;
        else break;
     }
     //update the maximum length if current increasing sequence is longer than previous 
     //values and update its starting pointer max_pos
     if (j-i>length_max){
	max_pos = i;
	length_max = j-i;
     } 
  }
  // corner case where length of max increasing sequence is one. 
  if (length_max==1){
     printf("No increasing sequence! \n");
     return NULL;
  }
  else{
     printf("position of the starting element is %d, and the longest increasing sequence is %d integer long.\n", max_pos, length_max);
     return seq+max_pos;
  }
}

