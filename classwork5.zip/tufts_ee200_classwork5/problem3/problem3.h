#ifndef PROBLEM3_H
#define PROBLEM3_H

int* find_sequence(int* seq, int n);

#endif
