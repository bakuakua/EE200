#ifndef PROBLEM2_H
#define PROBLEM2_H

int* find_min(int* array, int n);

#endif
