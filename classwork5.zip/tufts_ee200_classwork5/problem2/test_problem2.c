
#include "problem2.h"
#include <stdio.h>

int main(int argc, char* argv[])
{

  int arr[] = {1,2,3,4,5,6,7,8};
  int arr1[] = {-1,-2,-3,-4};
  int arr2[] = {99};
  int arr3[] = {};
  int *min;
  int *min1;
  int *min2;
  int *min3;
  min = find_min(arr, 8);
  min1 = find_min(arr1, 4);
  min2 = find_min(arr2, 1);
  min3 = find_min(arr3,0);
  printf("%d\n", *min);
  printf("%d\n", *min1);
  printf("%d\n", *min2);
  
  if(min3)printf("min3 is not null\n");
  else printf("min3 is null\n");
  return(0);
}

