
#include "problem2.h"
#include <stdio.h>

int* find_min(int* array, int n)
{
  // check if input array is empty
  //check for null pointer
  if(array == NULL) return NULL; 
  if(n == 0) return NULL;
  // iterate through the array while updating the pointer to minimum value.
  // pointer to minimum is initialized as the begining of the array
  else{ 
  	int* min = array;
    	int i;
    	for(i = 0; i<n;i++){
		if(*(array+i)<*min) min = (array+i);
	}
	return min;
  }
}

