
#include "problem3.h"
#include <stdio.h>

int main(int argc, char* argv[])
{

  // Put anything here that you think is appropriate to test your function
  // You can define triangles here, since the struct is declared in the header
  Triangle t1;
  Triangle t2;
  Point a1, b1, c1, a2, b2, c2;
  a1.x = 0;a1.y = 0;
  b1.x = 0;b1.y = 4;
  c1.x = 6;c1.y = 0;
  a2.x = 0;a2.y = 0; 
  b2.x = 0;b2.y = 6;
  c2.x = 9;c2.y = 0;
  t1.a = a1;t1.b = b1;t1.c = c1;
  t2.a = a2;t2.b = b2;t2.c = c2;
  Triangle* t = getLarger(&t1,&t2);
  printf("the Larger triangle has points (%lf, %lf), (%lf, %lf), (%lf, %lf)\n", t->a.x,t->a.y,t->b.x,t->b.y,t->c.x,t->c.y);
  Triangle t3;
  Triangle* ts = getLarger(&t3,&t2);
  printf("the Larger triangle has points (%lf, %lf), (%lf, %lf), (%lf, %lf)\n", ts->a.x,ts->a.y,ts->b.x,ts->b.y,ts->c.x,ts->c.y);
  Triangle* tt = getLarger(&t3, &t1);
  printf("the Larger triangle has points (%lf, %lf), (%lf, %lf), (%lf, %lf)\n", tt->a.x,tt->a.y,tt->b.x,tt->b.y,tt->c.x,tt->c.y);
  return(0);
}

