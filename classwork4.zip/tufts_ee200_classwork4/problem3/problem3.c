
#include "problem3.h"
#include <stdio.h>
#include <math.h>
double getS(double a, double b, double c){
    return(0.5*(a+b+c));
}

double getLength(Point a, Point b){
     return (sqrt(pow(a.x-b.x,2)+pow(a.y-b.y,2)));
}
double getArea(const Triangle* d){
    double a = getLength(d->a,d->b);
    double b = getLength(d->b,d->c);
    double c = getLength(d->c,d->a);
    double s = getS(a,b,c);
    return(sqrt(s*(s-a)*(s-b)*(s-c)));
}

Triangle* getLarger(const Triangle* first, const Triangle* second)
{

  // Fill in this function

  // You'll want to replace this with something that returns a meaningful
  // resulti.
  if (first != NULL && second == NULL) return (Triangle*) first;
  else if (first == NULL && second != NULL) return (Triangle*) second;
  else if (first == NULL && second == NULL) return (Triangle*) first;
  else{
  const Triangle* t;
  double Area1 = getArea(first);
  double Area2 = getArea(second);
  if (Area1 > Area2) t = first;
  else if(Area1 < Area2) t = second;
  else{
      printf("equal area\n");
      t = first;
  }
  return (Triangle* )t;
  }  
}

