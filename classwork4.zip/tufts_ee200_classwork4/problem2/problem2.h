#ifndef PROBLEM2_H
#define PROBLEM2_H

#include <time.h>

void print_time(time_t time);

#endif
