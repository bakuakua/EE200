
#include "problem2.h"
#include <stdio.h>
#include <time.h>

void print_time(time_t time)
{

  // Fill in this function
  struct tm* t;
  t = gmtime(&time);
  char buff[80];
  strftime(buff,80,"%A, %B %d, %Y %T",t);
  puts(buff); 
}

