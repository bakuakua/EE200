
#include "problem2.h"


int main(int argc, char* argv[])
{

  // Put anything here that you think is appropriate to test your function
  // e.g, print_time(10);
  print_time(10);
  print_time(2000000);
  time_t t;
  time(&t);
  print_time(t); 
  return(0);
}

