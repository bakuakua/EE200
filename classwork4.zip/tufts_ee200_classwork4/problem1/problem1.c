#include <stdio.h>
#include <math.h>

double calculate(double x, char operation, double y)
{
	double result;
	switch(operation){
		case '+': 
			result = x + y;
			break;	
		case '-':
			result = x - y;
			break;
		case '*':
			result = x * y;
			break;
		case '/':
			result = x / y;
			break;
		case '^':
			result = pow(x,y);
			break;
		default:
			printf("Invalid math operator. \n");	
			break;
	}
  
  return(result); 
}

int main(int argc, char* argv[])
{
  double num1, num2;
  char operator;
  scanf("%lf %c %lf", &num1, &operator, &num2);
  double result = calculate(num1, operator, num2);
  printf("The result is %.3f\n", result);
  return(0);
}

