
#include "problem3.h"
#include <stdio.h>
#include <math.h>
double calculate(double x, char operation, double y)
{
	double result;
	switch(operation){
		case '+': 
			result = x + y;
			break;	
		case '-':
			result = x - y;
			break;
		case '*':
			result = x * y;
			break;
		case '/':
			result = x / y;
			break;
		case '^':
			result = pow(x,y);
			break;
		default:
			printf("Invalid math operator. \n");	
			break;
	}
  
  return(result); 
}

