#ifndef PROBLEM3_H
#define PROBLEM3_H

double calculate(double x, char operation, double y);

#endif
