
#include "problem3.h"
#include <stdio.h>

int main(int argc, char* argv[])
{

  // Put anything here that you think is appropriate to test your function
  // e.g, double result = calculate(37, '+', 1);
  //      if(result ...
  double result1 = calculate(37, '+', 1);
  double result2 = calculate(1, '-', 2.43);
  double result3 = calculate(10, '*', 0.5);
  double result4 = calculate(16, '/', 0);
  double result5 = calculate(2, '^', 8);
  printf("results: %.2f, %.2f, %.2f, %.2f, %.2f\n", result1, result2, result3, result4, result5);
  return(0);
}

