
#include "problem1.h"
#include <stdio.h>

int print_factors(int n)
{
	//case where input is valid
	printf("=======printing prime factors of %d .=======\n", n);
	if(n <= 1){	
		return (-1);
	}
	else{
	int i;
	//find the factors n while checking their primality
		for(i = 2; i<=n; i++){
			if (n%i == 0){
				n/=i;
				printf(" %d,", i );
				i--;
			}
		}
    }
  printf("\n");
  return(0); 
}


