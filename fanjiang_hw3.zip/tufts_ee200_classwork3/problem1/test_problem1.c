
#include "problem1.h"


int main(int argc, char* argv[])
{

  // Put anything here that you think is appropriate to test your function
  // e.g, print_factors(10);
  // or int success = print_factors(17);
  print_factors(10);
  print_factors(17);
  print_factors(23);
  print_factors(120);
  print_factors(2);
  print_factors(0);
  print_factors(-1);
  print_factors(315);
  return(0);
}

