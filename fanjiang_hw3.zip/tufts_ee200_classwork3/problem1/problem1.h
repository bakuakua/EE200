#ifndef PROBLEM1_H
#define PROBLEM1_H

int print_factors(int n);

#endif
