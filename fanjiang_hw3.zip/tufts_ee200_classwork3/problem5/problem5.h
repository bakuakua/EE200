#ifndef PROBLEM5_H
#define PROBLEM5_H

void print_random(int n, int max);

#endif
