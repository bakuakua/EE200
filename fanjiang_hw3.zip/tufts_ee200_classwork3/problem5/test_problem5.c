
#include "problem5.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char* argv[])
{

  // Put anything here that you think is appropriate to test your function
	int n1 = 5; int max1 = 100;
    srand(time(0));
    print_random(n1,max1);
  return(0);
}

