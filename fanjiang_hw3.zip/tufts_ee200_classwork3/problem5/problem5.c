
#include "problem5.h"
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

void print_random(int n, int max)
{

  // Fill in this function
	int i;
	for(i = 0;i < n; i++){
		int rn = (rand()%(max+1));
		printf("%d ", rn);
	}
}

