
#include "problem2.h"
#include <stdio.h>

int find_power(int n)
{
	if (n<1){
                printf("invalid input\n");
		return -1;
	}
	int base = 2;
        int prod = 1;
	while (prod <= n){
		prod*=base; 
	}
	printf("Largerst power of 2 less than or equal to %d is %d. \n", n, prod/2);
	return prod/2;
}


