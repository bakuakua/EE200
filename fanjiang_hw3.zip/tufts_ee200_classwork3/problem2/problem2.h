#ifndef PROBLEM2_H
#define PROBLEM2_H

int find_power(int n);

#endif
