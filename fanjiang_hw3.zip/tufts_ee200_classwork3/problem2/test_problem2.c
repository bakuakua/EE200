
#include "problem2.h"
#include <stdio.h>

int main(int argc, char* argv[])
{

  // Put anything here that you think is appropriate to test your function
  // e.g., int result = find_power(17)
  int result = find_power(17);
  result = find_power(2);
  result = find_power(0);
  result = find_power(128);
  result = find_power(315);
  result = find_power(1);

  return(0);
}

